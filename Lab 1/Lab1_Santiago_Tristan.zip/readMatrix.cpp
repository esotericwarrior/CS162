/*********************************************************************
** Program name: readMatrix.cpp
** Author: Tristan Santiago
** Date: January 14, 2018
** Description: readMatrix.cpp contains the function definition for
** the void readMatrix() function, which is used to prompt the user
** to enter the appropriate number of integers needed to fill the
** array.
*********************************************************************/
#include "readMatrix.hpp"
#include <iostream>
using namespace std;

/****************************************************************
 * 		void readMatrix(int **array, int size)		*
 * This function takes two parameters a pointer to a 2D array	*
 * and an integer as the size of the matrix, which the user	*
 * determines. It also prompts the user to enter the elements	*
 * of the array, using a for loop to fill the matrix.		*
 ***************************************************************/
void readMatrix(int **array, int size)
{
    // Prompt user to enter the elements of the array.
    cout << "Please enter " << size*size << " integers." << endl;
	// Fill the array with user inputted integers.
    	for (int i = 0; i < size; ++i) {
    	for (int j = 0; j < size; ++j) {
    	cin >> array[i][j]; }}
    	    
    	// Display the array to the screen.
	for (int i = 0; i < size; ++i) {
	for (int j = 0; j < size; ++j) {
		cout << array[i][j] << "  "; }
		cout << endl; }
	    	cout << endl;
}
