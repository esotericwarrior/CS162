/*********************************************************************
** Program name: determinant.cpp
** Author: Tristan Santiago
** Date: January 14, 2018
** Description: determinant.cpp includes the header determinant.hpp
** file and defines the int determinant() function for use in
** main.cpp. The int determinant() functions takes two parameters:
** a pointer to a 2D array and an integer as the size of the matrix,
** which the user determines.
*********************************************************************/
#include "determinant.hpp"
#include <iostream>
using namespace std;

/****************************************************************
 * 		int determinant(int **array, int size)		*
 * The int determinant function takes a pointer to a 2D array	*
 * and an integer as the size of the matrix as parameters, then	*
 * uses those arguments to calculate the determinant of either	*
 * a 2*2 or 3*3 matrix, as specified by the user. It then	*
 * displays the matrix and the determinant to the screen.	*
 ***************************************************************/
int determinant(int **array, int size)
{
// Use an if statement to determine which formula should be used to
// calculate the determinant.
if(size == 2)	// If the size of the matrix is 2, use this formula.
{
	// Define the necessary variable needed to output the answer.
	int answer;
	// The formula used to calculate the determinant of a 2*2 matrix
	// is ad-bc. Thus, the answer is equal to:
	answer = (array[0][0] * array[1][1]) - (array[0][1] * array[1][0]);
	cout << "The determinant of the 2x2 matrix is: " << answer << endl;
}

// If the size of the array isn't 2, then it's 3, so use the following
// formula.
else
{
	// Define the necessary variable needed to output the answer.
	int answer2;
	
	// Visual representation of a 3*3 matrix:
	// [A B C]
	// [D E F]
	// [G H I]

	// Matrix translated into the elements of a 2D array.
	// [(0,0)(0,1)(0,2)]
	// [(1,0)(1,1)(1,2)]
	// [(2,0)(2,1)(2,2)]

// Formula used to calculate the determinant of a 3*3 matrix:
// |A| = a(ei − fh) − b(di − fg) + c(dh − eg)
answer2 = (array[0][0] * ((array[1][1] * array[2][2]) - (array[2][1] * array[1][2])))
- (array[1][0] * ((array[0][1] * array[2][2]) - (array[2][1] * array[0][2])))
+ (array[2][0] * ((array[0][1] * array[1][2]) - (array[1][1] * array[0][2])));
	cout << "The determinant of a 3x3 matrix is: " << answer2 << endl;
}
}
