/*********************************************************************
** Program name: readMatrix.hpp
** Author: Tristan Santiago
** Date: January 1, 2018
** Description: readMatrix.hpp contains the function prototype for
** the readMatrix() function, which is used to fill either a 2x2 or
** a 3x3 matrix, as specified by the user.
*********************************************************************/
#ifndef READMATRIX_HPP
#define READMATRIX_HPP

void readMatrix(int **a, int);  // function prototype

#endif
