/*********************************************************************
** Program name: determinant.hpp
** Author: Tristan Santiago
** Date: January 14, 2018
** Description: determinant.hpp contains the function prototype for
** the int determinant() function, which is used in main.cpp to
** calculate the determinant of either a 2*2 or 3*3 matrix.
*********************************************************************/
#ifndef DETERMINANT_HPP
#define DETERMINANT_HPP

int determinant(int **a, int);  // function prototype

#endif
