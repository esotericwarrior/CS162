/*********************************************************************
** Program name: main.cpp
** Author: Tristan Santiago
** Date: January 14, 2018
** Description: main.cpp includes both readMatrix.cpp and
** determinant.cpp and all necessary header files, which are all
** needed to make the program run properly.
*********************************************************************/
#include <iostream>
#include <stdlib.h>
#include "readMatrix.cpp"
#include "determinant.cpp"
using namespace std;

int main()
{
    int size;  // User-defined variable used to determine the size of the matrix.

    	// Prompt user to determine the size of the matrix.
	cout << "Please choose your size of matrix by entering “2” for a 2x2 matrix "
	<< "or “3” for a 3x3 matrix." << endl;
	// User's input will be stored in size and used to determine the size of the
	// matrix.
	cin >> size;

	// while(1) begins an infinite loop that will only break if the user
	// enters 2 or 3. This code was borrowed from:
	// https://www.hackerearth.com/practice/notes/validating-user-input-in-c/
	while(1)
	{
		if(cin.fail()) // If the user's input is not an integer:
			{
				cin.clear(); // Clears the error flag on cin.
				//https://stackoverflow.com/questions/5131647/why-
				//would-we-call-cin-clear-and-cin-ignore-after-reading
				//-input
				cin.ignore(100, '\n'); // Skips to the next newline and
				// skips 100 characters
				cout << "Please enter an integer." << endl; // Asks for
				// input again
				cin >> size;
			}
		// Break the loop if the user enters 2 or 3.
		if(!cin.fail() && (size == 2 || size == 3))
		break;
		
		// If the user enters an integer that isn't 2 or 3:
		else
		{
				cin.clear();
				cin.ignore(100, '\n');
				cout << "Please enter a 2 or a 3."<<endl;
				cin >> size;
		}
	}

/************************************************************************
 * Dynamically allocate a two-dimensional array, based on the size      *
 * obtained from the use.						*
 ***********************************************************************/
	        int** ipArray = new int*[size];
	        for (int i = 0; i < size; ++i)
	        {
		        ipArray[i] = new int[size];
	        }
    
            // Call readMatrix function to prompt user to enter necessary
            // number of integers for the matrix and display it afterwards.
            readMatrix(ipArray, size);
            
            // Call determinant function to calculate and display the determinant
            // of the matrix.
           determinant(ipArray, size);
           	// Deallocate
			for (int i = 0; i < size; ++i) {
			delete[] ipArray[i];
			}
			delete[] ipArray;
}
